"""
🍽️ Home Kitchen – One-Click Launcher
Fixes included:
  ✅ ngrok warning page skipped automatically
  ✅ Admin panel password protected (works on public link too)
  ✅ WhatsApp message sent to you on every new booking (via CallMeBot)
"""

import subprocess
import sys
import time
import threading
import webbrowser
import urllib.parse
import urllib.request

# ── Auto-install missing packages ──────────────────────────────────────────
def install(pkg):
    print(f"  📦 Installing {pkg}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"])

try:
    from flask import Flask, render_template, request, redirect, url_for, session, Response
except ImportError:
    install("flask")
    from flask import Flask, render_template, request, redirect, url_for, session, Response

try:
    from pyngrok import ngrok
except ImportError:
    install("pyngrok")
    from pyngrok import ngrok

import json, os
from datetime import datetime
from functools import wraps

# ════════════════════════════════════════════════════════════════════════════
#  ⚙️  YOUR SETTINGS — Fill these in before running!
# ════════════════════════════════════════════════════════════════════════════

WHATSAPP_NUMBER  = "919030921654"   # Your number: country code + digits, no + or spaces
NGROK_AUTH_TOKEN = "312NBjpDBg7F4PqnGYnk0Ib1hrA_3hEn2Z7ZTa3VRLAWrpwu9"               # From https://dashboard.ngrok.com/get-started/your-authtoken

# Admin panel password (to protect your admin page on the public link)
ADMIN_USERNAME   = "admin"          # Change this to any username you like
ADMIN_PASSWORD   = "kitchen123"     # Change this to a strong password

# WhatsApp notifications (FREE via CallMeBot)
# Step 1: Save +34 644 59 44 19 in your contacts as "CallMeBot"
# Step 2: Send this WhatsApp message to that number:  I allow callmebot to send me messages
# Step 3: You'll receive your API key. Paste it below.
CALLMEBOT_API_KEY = ""              # e.g. "123456"  — leave empty to skip WA notifications

PORT = 5000

# ════════════════════════════════════════════════════════════════════════════

BOOKINGS_FILE = "bookings.json"
app = Flask(__name__)
app.secret_key = "homekitchen_secret_2025"

# ── FIX 1: Skip ngrok browser warning for ALL responses ─────────────────
@app.after_request
def skip_ngrok_warning(response):
    response.headers["ngrok-skip-browser-warning"] = "true"
    response.headers["Access-Control-Allow-Origin"] = "*"
    return response

# ── FIX 2: Admin password protection ────────────────────────────────────
def check_auth(username, password):
    return username == ADMIN_USERNAME and password == ADMIN_PASSWORD

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return Response(
                '🔐 Admin access required. Enter your username and password.',
                401,
                {'WWW-Authenticate': 'Basic realm="Admin Panel"'}
            )
        return f(*args, **kwargs)
    return decorated

# ── FIX 3: Send WhatsApp notification via CallMeBot ─────────────────────
def send_whatsapp_notification(booking):
    if not CALLMEBOT_API_KEY or not CALLMEBOT_API_KEY.strip():
        return  # Skip if not configured

    msg = (
        f"🍽️ New Booking!\n"
        f"Name: {booking['name']}\n"
        f"Phone: {booking['phone']}\n"
        f"Date: {booking['date']} | {booking['time']}\n"
        f"Guests: {booking['guests']}\n"
        f"Meal: {booking['meal_type']}\n"
        f"Notes: {booking['special_requests'] or 'None'}"
    )
    encoded_msg = urllib.parse.quote(msg)
    url = (
        f"https://api.callmebot.com/whatsapp.php"
        f"?phone={WHATSAPP_NUMBER}&text={encoded_msg}&apikey={CALLMEBOT_API_KEY}"
    )
    try:
        urllib.request.urlopen(url, timeout=10)
        print(f"  📲 WhatsApp notification sent for booking by {booking['name']}")
    except Exception as e:
        print(f"  ⚠️  WhatsApp notification failed: {e}")

# ── Helpers ─────────────────────────────────────────────────────────────
def load_bookings():
    if os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, "r") as f:
            return json.load(f)
    return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, "w") as f:
        json.dump(bookings, f, indent=2)

# ── Routes ───────────────────────────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html", whatsapp=WHATSAPP_NUMBER)

@app.route("/book", methods=["POST"])
def book():
    bookings = load_bookings()
    booking = {
        "id": len(bookings) + 1,
        "name": request.form.get("name"),
        "phone": request.form.get("phone"),
        "email": request.form.get("email"),
        "date": request.form.get("date"),
        "time": request.form.get("time"),
        "guests": request.form.get("guests"),
        "meal_type": request.form.get("meal_type"),
        "special_requests": request.form.get("special_requests"),
        "status": "Pending",
        "booked_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    bookings.append(booking)
    save_bookings(bookings)

    # Send WhatsApp notification in background (so page doesn't slow down)
    t = threading.Thread(target=send_whatsapp_notification, args=(booking,), daemon=True)
    t.start()

    return redirect(url_for("success", name=booking["name"]))

@app.route("/success")
def success():
    name = request.args.get("name", "")
    return render_template("success.html", name=name, whatsapp=WHATSAPP_NUMBER)

@app.route("/admin")
@requires_auth
def admin():
    bookings = load_bookings()
    bookings_sorted = sorted(bookings, key=lambda x: x["booked_at"], reverse=True)
    return render_template("admin.html", bookings=bookings_sorted, whatsapp=WHATSAPP_NUMBER)

@app.route("/admin/update/<int:booking_id>", methods=["POST"])
@requires_auth
def update_status(booking_id):
    bookings = load_bookings()
    status = request.form.get("status")
    for b in bookings:
        if b["id"] == booking_id:
            b["status"] = status
            break
    save_bookings(bookings)
    return redirect(url_for("admin"))

@app.route("/admin/delete/<int:booking_id>", methods=["POST"])
@requires_auth
def delete_booking(booking_id):
    bookings = load_bookings()
    bookings = [b for b in bookings if b["id"] != booking_id]
    save_bookings(bookings)
    return redirect(url_for("admin"))

# ── Startup ─────────────────────────────────────────────────────────────
def start_ngrok():
    time.sleep(1.5)
    try:
        if NGROK_AUTH_TOKEN:
            ngrok.set_auth_token(NGROK_AUTH_TOKEN)

        tunnel = ngrok.connect(PORT, "http")
        public_url = tunnel.public_url

        print("\n" + "═" * 60)
        print("  ✅  YOUR APP IS LIVE!")
        print("═" * 60)
        print(f"\n  🌐  Customer Link  :  {public_url}")
        print(f"  🔐  Admin Panel    :  {public_url}/admin")
        print(f"  🖥️   Local Admin    :  http://localhost:{PORT}/admin")
        print(f"\n  👤  Admin Login:")
        print(f"      Username : {ADMIN_USERNAME}")
        print(f"      Password : {ADMIN_PASSWORD}")
        if CALLMEBOT_API_KEY:
            print(f"\n  📲  WhatsApp alerts : ENABLED ✅")
        else:
            print(f"\n  📲  WhatsApp alerts : Not set up yet (see README)")
        print("\n  ⚠️   Keep this window open while the app runs.")
        print("      Press CTRL+C to stop.\n")
        print("═" * 60 + "\n")

        with open("my_public_link.txt", "w") as f:
            f.write(f"Customer Booking Link:\n{public_url}\n\nAdmin Panel:\n{public_url}/admin\n\nAdmin Username: {ADMIN_USERNAME}\nAdmin Password: {ADMIN_PASSWORD}\n")

        webbrowser.open(f"http://localhost:{PORT}/admin")

    except Exception as e:
        print(f"\n  ⚠️  ngrok error: {e}")
        print(f"  Local access still works: http://localhost:{PORT}\n")

if __name__ == "__main__":
    print("\n" + "═" * 60)
    print("  🍽️   Home Kitchen – Food Booking App")
    print("═" * 60)

    if not NGROK_AUTH_TOKEN:
        print("\n  ⚠️  NGROK_AUTH_TOKEN is empty!")
        print("  👉  Get your free token from: https://dashboard.ngrok.com")
        print("  👉  Paste it in start.py at the top\n")

    t = threading.Thread(target=start_ngrok, daemon=True)
    t.start()

    app.run(port=PORT, debug=False, use_reloader=False)
