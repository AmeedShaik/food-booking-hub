from flask import Flask, render_template, request, redirect, url_for, jsonify
import json
import os
from datetime import datetime

app = Flask(__name__)

BOOKINGS_FILE = "bookings.json"

def load_bookings():
    if os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, "r") as f:
            return json.load(f)
    return []

def save_bookings(bookings):
    with open(BOOKINGS_FILE, "w") as f:
        json.dump(bookings, f, indent=2)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/book", methods=["POST"])
def book():
    bookings = load_bookings()
    booking = {
        "id": len(bookings) + 1,
        "name": request.form.get("name"),
        "phone": request.form.get("phone"),
        "email": request.form.get("email"),
        "date": request.form.get("date"),
        "time": request.form.get("time"),
        "guests": request.form.get("guests"),
        "meal_type": request.form.get("meal_type"),
        "special_requests": request.form.get("special_requests"),
        "status": "Pending",
        "booked_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    bookings.append(booking)
    save_bookings(bookings)
    return redirect(url_for("success", name=booking["name"]))

@app.route("/success")
def success():
    name = request.args.get("name", "")
    return render_template("success.html", name=name)

@app.route("/admin")
def admin():
    bookings = load_bookings()
    bookings_sorted = sorted(bookings, key=lambda x: x["booked_at"], reverse=True)
    return render_template("admin.html", bookings=bookings_sorted)

@app.route("/admin/update/<int:booking_id>", methods=["POST"])
def update_status(booking_id):
    bookings = load_bookings()
    status = request.form.get("status")
    for b in bookings:
        if b["id"] == booking_id:
            b["status"] = status
            break
    save_bookings(bookings)
    return redirect(url_for("admin"))

@app.route("/admin/delete/<int:booking_id>", methods=["POST"])
def delete_booking(booking_id):
    bookings = load_bookings()
    bookings = [b for b in bookings if b["id"] != booking_id]
    save_bookings(bookings)
    return redirect(url_for("admin"))

if __name__ == "__main__":
    print("\n✅ Food Booking App is running!")
    print("🌐 Open your browser and go to: http://localhost:5000")
    print("🔐 Admin panel: http://localhost:5000/admin")
    print("Press CTRL+C to stop the server\n")
    app.run(debug=True, port=5000)
