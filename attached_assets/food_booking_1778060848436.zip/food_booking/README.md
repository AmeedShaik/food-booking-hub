# 🍽️ Home Kitchen – Food Booking App with ngrok

Share your booking website with ANYONE in the world — for free!

---

## 📁 Files in This Package

```
food_booking/
├── START_APP.bat        <- Double-click this to launch everything (Windows)
├── start.py             <- Main launcher (Flask + ngrok together)
├── requirements.txt     <- Required Python packages
├── bookings.json        <- Bookings saved here (auto-created)
├── my_public_link.txt   <- Your public link saved here after launch
└── templates/
    ├── index.html       <- Customer booking website
    ├── success.html     <- Confirmation page
    └── admin.html       <- Your private admin panel
```

---

## One-Time Setup (Do This First)

### Step 1 – Get a Free ngrok Account
1. Go to: https://dashboard.ngrok.com/signup
2. Sign up (free, no credit card)
3. Go to: https://dashboard.ngrok.com/get-started/your-authtoken
4. Copy your Authtoken

### Step 2 – Edit start.py
Open start.py in Notepad and fill in these 2 lines:

  WHATSAPP_NUMBER = "919876543210"     <- country code + number, no spaces
  NGROK_AUTH_TOKEN = "your_token_here" <- paste from ngrok dashboard

Save the file.

---

## How to Run Every Day

WINDOWS: Double-click START_APP.bat — done!

MAC/LINUX: Open terminal in folder and run:
  python start.py

The app will:
- Install packages automatically
- Start your website
- Print your PUBLIC LINK in the terminal
- Open admin panel in browser
- Save link to my_public_link.txt

---

## Share Your Link

After starting, the terminal shows:

  Your Public Link: https://abc123.ngrok-free.app

Share this on WhatsApp, Instagram, etc.
The link changes each time you restart — just share the new one.

---

## Admin Panel

Go to: http://localhost:5000/admin

- See all bookings live
- Confirm / Cancel / Complete bookings
- Tap customer phone to open WhatsApp directly

---

## Troubleshooting

Problem: pip not found
Fix: python -m pip install flask pyngrok

Problem: ngrok token error
Fix: Re-copy token from dashboard.ngrok.com

Problem: Port already in use
Fix: Change PORT = 5000 to PORT = 5001 in start.py
