@echo off
title Home Kitchen - Food Booking App
color 0A
echo.
echo  ==========================================
echo   Launching Home Kitchen Booking App...
echo  ==========================================
echo.

cd /d "%~dp0"

echo  Installing required packages...
pip install flask pyngrok -q

echo.
echo  Starting app... (browser will open automatically)
echo.
python start.py

pause
